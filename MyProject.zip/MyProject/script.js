// سنة الفوتر
const yearSpan = document.getElementById("year");
if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
}

// التنقل إلى قسم الأعمال من زر الهيرو
const scrollToPortfolioBtn = document.getElementById("scrollToPortfolio");
if (scrollToPortfolioBtn) {
    scrollToPortfolioBtn.addEventListener("click", () => {
        const portfolioSection = document.getElementById("portfolio");
        if (portfolioSection) {
            portfolioSection.scrollIntoView({ behavior: "smooth" });
        }
    });
}

// فلترة الأعمال
const filterButtons = document.querySelectorAll(".filter-btn");
const portfolioCards = document.querySelectorAll(".portfolio-card");

filterButtons.forEach((btn) => {
    btn.addEventListener("click", () => {
        const filter = btn.getAttribute("data-filter");

        filterButtons.forEach((b) => b.classList.remove("active"));
        btn.classList.add("active");

        portfolioCards.forEach((card) => {
            const category = card.getAttribute("data-category");
            if (filter === "all" || category === filter) {
                card.style.display = "block";
                card.style.opacity = "1";
            } else {
                card.style.opacity = "0";
                setTimeout(() => {
                    card.style.display = "none";
                }, 200);
            }
        });
    });
});

// نموذج التواصل (محاكاة إرسال)
const contactForm = document.getElementById("contactForm");
const formStatus = document.getElementById("formStatus");

if (contactForm && formStatus) {
    contactForm.addEventListener("submit", (e) => {
        e.preventDefault();

        const name = document.getElementById("name").value.trim();
        const email = document.getElementById("email").value.trim();
        const budget = document.getElementById("budget").value;
        const message = document.getElementById("message").value.trim();

        if (!name || !email || !message) {
            formStatus.textContent = "يرجى تعبئة الحقول الأساسية قبل الإرسال.";
            formStatus.style.color = "#ef4444";
            return;
        }

        formStatus.textContent = "تم استلام طلبك بنجاح! سنتواصل معك قريباً.";
        formStatus.style.color = "#22c55e";

        contactForm.reset();

        setTimeout(() => {
            formStatus.textContent = "";
        }, 4000);
    });
}

// قائمة الموبايل
const navToggle = document.getElementById("navToggle");
const nav = document.querySelector(".nav");

if (navToggle && nav) {
    navToggle.addEventListener("click", () => {
        nav.classList.toggle("open");
    });
}
